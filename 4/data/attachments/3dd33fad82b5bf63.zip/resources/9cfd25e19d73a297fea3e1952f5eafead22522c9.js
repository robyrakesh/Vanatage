(function () {
	'use strict';



})();
//# sourceMappingURL=wpstg-blank-loader.js.map
