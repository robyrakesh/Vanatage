// AVOID CONSOLE ERRORS IN BROWSERS THAT LACK A CONSOLE
(function() {
    var method;
    var noop = function noop() {};
    var methods = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeStamp', 'trace', 'warn'
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
}());

// REMAP jQUERY TO $
(function($){

$(window).load(function() {

    // Mobile Nav Trigger
    $('#nav #trigger').click(function(){
        $('#nav > ul').slideToggle();
    });

    $('.hero.home .arrow').click(function() {
        var header = $("#header").height()
        $('html, body').animate({
            scrollTop: $(".content-bar.home").offset().top - header
        }, 2000);
    });

    // Mobile Nav Dropdown Trigger
    $('#nav ul li .fa-caret-down').click(function(){
        $(this).parent().find('> .dropdown').slideToggle();
    });

    $('.browser-slide .slick').slick({
        infinite: false,
        fade: true,
        cssEase: 'linear',
        arrows: false
    });

    $('.browser-slide .fa-ul li').each( function(i) {
        $('.browser-slide .fa-ul .slide-' + i).click(function(){
            $(this).siblings().removeClass('active');
            $(this).addClass('active');
            $(this).parents().siblings('.browser-slide .slick').slick('slickGoTo', i);
        });
    });

    $('.standard.slick').slick({
        infinite: true,
        speed: 300,
        draggable: false,
        autoplay: false,
        arrows: true,
        slidesToShow: 6,
        responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 4,
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 2,
              }
            }
        ]
    });

    $('.smaller.slick').slick({
        infinite: true,
        speed: 300,
        draggable: false,
        autoplay: false,
        arrows: true,
        slidesToShow: 4,
        responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 4,
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 2,
              }
            }
        ]
    });

    $(".chosen-select").chosen({
         width: "100%",
         disable_search_threshold: 10
    });

    $('.blog-listing').masonry({
        itemSelector: '.post',
        percentPostion: true,
        columnWidth: '.grid-sizer',
        gutter: '.gutter-sizer'
    });

    $('.price-chart .trigger').click(function(){
        $(this).siblings('.hidey').slideToggle();
        $(this).toggleClass('active');
    });

    var a = 0;
    $(window).scroll(function() {
      var oTop = $('#counter').offset().top - window.innerHeight;
      if (a == 0 && $(window).scrollTop() > oTop) {
        $('.counter-value').each(function() {
          var $this = $(this),
            countTo = $this.attr('data-count');
          $({
            countNum: $this.text()
          }).animate({
              countNum: countTo
            },
            {
              duration: 3000,
              easing: 'swing',
              step: function() {
                $this.text(Math.floor(this.countNum));
              },
              complete: function() {
                $this.text(this.countNum);
                //alert('finished');
              }
            });
        });
        a = 1;
      }
    });

});

$(document).ready(function (){



});

})(window.jQuery);
